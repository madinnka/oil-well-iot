
#define BLYNK_PRINT Serial
#include <SoftwareSerial.h>
#include <BlynkSimpleShieldEsp8266.h>

SoftwareSerial EspSerial(6, 7); // RX, TX

#define ESP8266_BAUD 9600
ESP8266 wifi(&EspSerial);

// Ваш токен
char auth[] = "ВАШ_ТОКЕН";
char ssid[] = "ВАШ_WiFi";
char pass[] = "ПАРОЛЬ_WiFi";

// Пины
#define PRESSURE_PIN A0
#define CURRENT_PIN  A1
#define VIBRATION_PIN 2
#define RELAY_PIN 3

bool manualControl = false;
bool manualState = false;

// Виртуальный пин для ручного управления
BLYNK_WRITE(V0) {
  manualControl = true;
  manualState = param.asInt();
}

void setup() {
  pinMode(VIBRATION_PIN, INPUT);
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);
  
  Serial.begin(9600);
  EspSerial.begin(ESP8266_BAUD);
  Blynk.begin(auth, wifi, ssid, pass);
}

void loop() {
  Blynk.run();
  
  int pressure = analogRead(PRESSURE_PIN);
  int currentVal = analogRead(CURRENT_PIN);
  float voltage = currentVal * (5.0 / 1023.0);
  float current = (voltage - 2.5) / 0.185;

  bool vibration = digitalRead(VIBRATION_PIN);
  bool lowPressure = pressure < 200;
  bool lowCurrent = abs(current) < 0.1;

  // Логика
  bool pumpOn = false;

  if (manualControl) {
    pumpOn = manualState;
  } else {
    if (!lowPressure && !lowCurrent && !vibration) {
      pumpOn = true;
    }
  }

  digitalWrite(RELAY_PIN, pumpOn ? HIGH : LOW);

  // Отправка данных в Blynk
  Blynk.virtualWrite(V1, pressure);
  Blynk.virtualWrite(V2, current);
  Blynk.virtualWrite(V3, vibration ? 1 : 0);
  Blynk.virtualWrite(V4, pumpOn ? 1 : 0);

  delay(2000);
}
